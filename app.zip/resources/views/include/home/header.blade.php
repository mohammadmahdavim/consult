<div class="header-toparea">
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-12">
                <div class="header-topinfo">
                    <ul>
                        <li><a href="tel_3A//+1-800-915-6270"><i class="fa fa-phone"></i>021-8451-3125</a></li>
                        <li><a href="https://www.instagram.com/kanoon.bartarha" target="_blank"><i class="fa fa-instagram"></i>kanoon.bartarha</a></li>
                        <!--<li><a href="mailto://contact@example.com"><i class="fa fa-whatsapp"></i>-->
                        <!--09210915874-->
                        <!--</a>-->
                        <!--</li>-->
                    </ul>
                </div>
            </div>
            <div class="col-md-5 col-12">
                <div class="header-topinfo text-right">
                    <ul>
                        <li><i class="fa fa-clock-o"></i>همه روزه</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
